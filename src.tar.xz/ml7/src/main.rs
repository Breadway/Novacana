mod az;
mod evals;
mod mcts;
mod net;
mod recorder;
mod sampling;
mod td_value;
mod tokens;

use std::time::Instant;

use rand::seq::SliceRandom;
use rand::thread_rng;

use burn::backend::Autodiff;
use burn::module::{AutodiffModule, Module};
use burn::record::{BinFileRecorder, FullPrecisionSettings};
use burn::tensor::backend::AutodiffBackend;
#[cfg(not(feature = "tch"))]
use burn_ndarray::{NdArray, NdArrayDevice};
#[cfg(feature = "tch")]
use burn_tch::{LibTorch, LibTorchDevice};

use az::{eval_win_rate, generate_az_games, AzSample};
use burn::tensor::backend::Backend;
use mcts::McConfig;
use net::Net;
use recorder::{generate_samples, Sample};
use td_value::{generate_td_samples, TdSample};
use tokens::{action_kind_name, ACTION_MAX, TokenSeq, NUM_ACTION_KINDS};

// ── CLI plumbing ─────────────────────────────────────────────────────────

fn flag_usize(args: &[String], flag: &str, default: usize) -> usize {
    args.windows(2).find(|w| w[0] == flag).and_then(|w| w[1].parse().ok()).unwrap_or(default)
}
fn flag_f32(args: &[String], flag: &str, default: f32) -> f32 {
    args.windows(2).find(|w| w[0] == flag).and_then(|w| w[1].parse().ok()).unwrap_or(default)
}
fn flag_str(args: &[String], flag: &str, default: &str) -> String {
    args.windows(2).find(|w| w[0] == flag).map(|w| w[1].clone()).unwrap_or_else(|| default.to_string())
}
fn has_flag(args: &[String], flag: &str) -> bool {
    args.iter().any(|a| a == flag)
}

// burn's FileRecorder uses PathBuf::set_extension() when writing, which
// REPLACES the extension rather than appending. A plain "{out_path}_best"
// suffix (found 2026-07-09, fidelity diagnostic) still collides whenever
// out_path itself already ends in ".bin": "foo.bin_best" has exactly one
// dot, so set_extension("bin") sees "bin_best" as THE extension and
// replaces it wholesale, collapsing back to "foo.bin" (verified via a
// standalone rustc repro, 2026-07-09 — the underscore fix alone wasn't
// enough, an out_path with an extension retriggers the same collision).
// Fix: strip any existing extension via file_stem() before appending
// "_best", so the constructed path never has more than the one dot
// set_extension() itself adds back. Shared by every checkpoint-saving
// command (bc/td-value/az) — do not reintroduce the bug via a fresh
// string-concat in a new command.
fn best_checkpoint_path(out_path: &str) -> String {
    let out_pb = std::path::Path::new(out_path);
    let stem = out_pb.file_stem().and_then(|s| s.to_str()).unwrap_or(out_path);
    let parent = out_pb.parent().map(|p| p.to_string_lossy().to_string()).unwrap_or_default();
    if parent.is_empty() {
        format!("{stem}_best")
    } else {
        format!("{parent}/{stem}_best")
    }
}

/// Same collision-avoidance as `best_checkpoint_path`, for AZ's numbered
/// snapshot pool (ASTRA7.md §4.3: "snapshot the model pool every 20
/// iterations") — `{stem}_iter{n}`, never `{out_path}_iter{n}` directly.
fn snapshot_path(out_path: &str, iter: usize) -> String {
    let out_pb = std::path::Path::new(out_path);
    let stem = out_pb.file_stem().and_then(|s| s.to_str()).unwrap_or(out_path);
    let parent = out_pb.parent().map(|p| p.to_string_lossy().to_string()).unwrap_or_default();
    if parent.is_empty() {
        format!("{stem}_iter{iter}")
    } else {
        format!("{parent}/{stem}_iter{iter}")
    }
}

fn main() {
    let args: Vec<String> = std::env::args().collect();

    if has_flag(&args, "bc") {
        cmd_bc(&args);
        return;
    }
    if has_flag(&args, "fidelity") {
        cmd_fidelity(&args);
        return;
    }
    if has_flag(&args, "winrate") {
        cmd_winrate(&args);
        return;
    }
    if has_flag(&args, "td-value") {
        cmd_td_value(&args);
        return;
    }
    if has_flag(&args, "value-rank") {
        cmd_value_rank(&args);
        return;
    }
    if has_flag(&args, "az") {
        cmd_az(&args);
        return;
    }

    println!("Usage:");
    println!("  novacana-ml7 bc [options]");
    println!("  novacana-ml7 fidelity --model <path> [options]");
    println!("  novacana-ml7 winrate --model <path> [options]");
    println!("  novacana-ml7 td-value --model <path> [options]");
    println!("  novacana-ml7 value-rank --model <path> [options]");
    println!("  novacana-ml7 az --model <path> [options]");
    println!();
    println!("BC (behavior cloning) options:");
    println!("  --out <path>          [models/astra7_bc.bin]");
    println!("  --model <path>        warm-start weights");
    println!("  --games <n>           pregenerate this many games upfront, reuse across epochs [0]");
    println!("  --chunk-games <n>     stream this many fresh games per epoch instead [2000]");
    println!("  --players <n>         [4]");
    println!("  --lr <f>              [0.0003]");
    println!("  --epochs <n>          [15]");
    println!("  --batch-size <n>      [64]");
    println!("  --label-smoothing <f> [0.05]");
    println!("  --val-games <n>       held-out games for best-checkpoint selection [200]");
    println!("  --winrate-every <n>   epochs between win-rate gate checks, 0=off [1]");
    println!("  --winrate-games <n>   games per win-rate check [150]");
    println!();
    println!("Fidelity options (per-ActionKind accuracy breakdown, ASTRA7.md §1.1/§10):");
    println!("  --model <path>        checkpoint to evaluate [models/astra7_bc_best.bin]");
    println!("  --val-games <n>       fresh games to evaluate against [200]");
    println!("  --players <n>         [4]");
    println!("  --batch-size <n>      [64]");
    println!();
    println!("Winrate options (ASTRA7.md §4.1/§2 milestone eval — greedy net vs AdvCPU, no search):");
    println!("  --model <path>        checkpoint to evaluate [models/astra7_bc_best.bin]");
    println!("  --games <n>           [200] (use >=1000 for a trustworthy milestone-gate reading)");
    println!("  --players <n>         [4]");
    println!();
    println!("TD-value options (ASTRA7.md §4.2 — frozen-trunk value-head training):");
    println!("  --model <path>        REQUIRED: BC checkpoint to warm-start the trunk from");
    println!("  --out <path>          [models/astra7_td.bin]");
    println!("  --chunk-games <n>     fresh self-play games generated per pass [1500]");
    println!("  --passes <n>          §4.2 says 2-3; each regenerates data fresh [3]");
    println!("  --players <n>         [4]");
    println!("  --temperature <f>     self-play sampling temperature [0.8]");
    println!("  --lr <f>              [0.001]");
    println!("  --batch-size <n>      [64]");
    println!("  --val-games <n>       held-out games for best-checkpoint selection [200]");
    println!();
    println!("value-rank options (ASTRA7.md §4.2 diagnostic, gate >=65%):");
    println!("  --model <path>        checkpoint to evaluate");
    println!("  --games <n>           AdvCPU self-play games to source decision points from [400]");
    println!("  --points <n>          decision points to score (subsampled) [1000]");
    println!("  --players <n>         [4]");
    println!();
    println!("AZ league options (ASTRA7.md §4.3):");
    println!("  --model <path>        REQUIRED: TD-value checkpoint to start the league from");
    println!("  --out <path>          [models/astra7_az.bin]");
    println!("  --iters <n>           [150]");
    println!("  --games-per-iter <n>  self-play games per iteration [150]");
    println!("  --players <n>         [4]");
    println!("  --sims <n>            MCTS sims/decision, floor 400 per §4.3/§8.5 [400]");
    println!("  --c-puct <f>          [1.5]");
    println!("  --dirichlet-eps <f>   [0.25]");
    println!("  --advcpu-share <f>    opponent-mix AdvCPU share [0.3]");
    println!("  --expert-share <f>    opponent-mix ExpertCpuPlayer share [0.15]");
    println!("  --window <n>          sliding replay window, samples [300000]");
    println!("  --batch-size <n>      [256]");
    println!("  --lr-start <f>        [0.00005]");
    println!("  --lr-end <f>          [0.00002]");
    println!("  --snapshot-every <n>  iterations between numbered snapshots [20]");
    println!("  --eval-every <n>      iterations between verified evals [10]");
    println!("  --eval-games <n>      in-loop eval games, >=600 per §2 [600]");
}

// ── BC training ────────────────────────────────────────────────────────

#[allow(clippy::too_many_arguments)]
fn run_bc<B: AutodiffBackend>(
    initial: Option<Net<B>>,
    out_path: &str,
    num_games: usize,
    chunk_games: usize,
    num_players: usize,
    lr: f32,
    epochs: usize,
    batch_size: usize,
    label_smoothing: f32,
    val_games: usize,
    winrate_every: usize,
    winrate_games: usize,
    device: &B::Device,
) where
    B::Device: Clone + Sync,
{
    let mut net = initial.unwrap_or_else(|| Net::fresh(device));
    let mut opt = net::make_optimizer::<B>();
    let mut rng = thread_rng();
    let recorder = BinFileRecorder::<FullPrecisionSettings>::new();

    // chunk_games == 0: generate all upfront and reuse across epochs (fine
    // for small demo runs). chunk_games > 0: fresh games every epoch —
    // ASTRA7.md §8.3: never pregenerate more than ~8-10K games at once.
    let pregenerated: Option<Vec<Sample>> = if chunk_games == 0 {
        println!("Generating BC data: {} games x {} players...", num_games, num_players);
        let t0 = Instant::now();
        let s = generate_samples(num_games, num_players);
        println!("  {} samples in {:.1}s", s.len(), t0.elapsed().as_secs_f32());
        Some(s)
    } else {
        println!("Chunked BC training: {} games/epoch x {} players", chunk_games, num_players);
        None
    };

    let val_samples: Vec<Sample> = if val_games > 0 {
        println!("Generating validation set: {} games...", val_games);
        let t0 = Instant::now();
        let v = generate_samples(val_games, num_players);
        println!("  {} val samples in {:.1}s", v.len(), t0.elapsed().as_secs_f32());
        v
    } else {
        Vec::new()
    };

    // LR warmup + cosine decay (ASTRA7.md §10: "cheap insurance" for the
    // scaled rented-GPU run). Total step count is an estimate (chunked mode
    // regenerates slightly different sample counts each epoch) using the
    // val-set's samples/game ratio as a stand-in for train data density —
    // exact step parity doesn't matter for a cosine schedule, only the
    // rough shape does. 5% warmup, floor of 50 steps so tiny smoke runs
    // don't warmup forever.
    let samples_per_game_est = if val_games > 0 {
        (val_samples.len() as f32 / val_games as f32).max(1.0)
    } else {
        1.0
    };
    let games_per_epoch_est = if chunk_games == 0 { num_games } else { chunk_games };
    let steps_per_epoch_est =
        ((games_per_epoch_est as f32 * samples_per_game_est) / batch_size as f32).ceil().max(1.0) as usize;
    let total_steps_est = (steps_per_epoch_est * epochs).max(1);
    let warmup_steps = (total_steps_est / 20).max(50);
    let mut global_step: usize = 0;

    let mut best_acc: f32 = -1.0;
    let best_path = best_checkpoint_path(out_path);

    for epoch in 0..epochs {
        let fresh: Vec<Sample>;
        let samples: &[Sample] = if let Some(ref s) = pregenerated {
            s
        } else {
            fresh = generate_samples(chunk_games, num_players);
            &fresh
        };

        let mut idx: Vec<usize> = (0..samples.len()).collect();
        idx.shuffle(&mut rng);

        // Progress heartbeat: per-epoch logging alone is blind at this scale
        // (a 300-game epoch can be thousands of batches) — print elapsed
        // time + batch index every HEARTBEAT_EVERY batches so a stalled vs.
        // slow-but-progressing run is distinguishable without guessing.
        const HEARTBEAT_EVERY: usize = 50;
        let total_batches = samples.len().div_ceil(batch_size).max(1);

        let (mut tpl, mut tvl, mut nb) = (0.0f64, 0.0f64, 0usize);
        let t0 = Instant::now();
        for chunk in idx.chunks(batch_size) {
            if chunk.len() < 2 {
                continue;
            }
            let seqs: Vec<TokenSeq> = chunk.iter().map(|&i| samples[i].tokens).collect();
            let targets: Vec<u16> = chunk.iter().map(|&i| samples[i].target).collect();
            let outcomes: Vec<f32> = chunk.iter().map(|&i| samples[i].outcome).collect();
            let lr_mult = if global_step < warmup_steps {
                (global_step + 1) as f32 / warmup_steps as f32
            } else {
                let progress = ((global_step - warmup_steps) as f32
                    / (total_steps_est.saturating_sub(warmup_steps)).max(1) as f32)
                    .min(1.0);
                0.5 * (1.0 + (std::f32::consts::PI * progress).cos())
            };
            let cur_lr = (lr * lr_mult) as f64;
            let (nn, pl, vl) = net::bc_train_step(net, &mut opt, cur_lr, &seqs, &targets, &outcomes, label_smoothing, device);
            net = nn;
            tpl += pl as f64;
            tvl += vl as f64;
            nb += 1;
            global_step += 1;
            if nb % HEARTBEAT_EVERY == 0 {
                let elapsed = t0.elapsed().as_secs_f32();
                println!(
                    "    heartbeat: batch {}/{}  policy={:.4} value={:.4}  lr={:.2e}  {:.2}s elapsed  ({:.3}s/batch)",
                    nb, total_batches, tpl / nb as f64, tvl / nb as f64, cur_lr, elapsed, elapsed / nb as f32
                );
            }
        }

        if !val_samples.is_empty() {
            // net.valid() (inner, non-autodiff backend): forward passes on
            // the autodiff backend accumulate graph state that only
            // backward() releases (ASTRA7.md §8.2).
            let vnet = net.valid();
            let vidx: Vec<usize> = (0..val_samples.len()).collect();
            let (mut correct, mut ce, mut n) = (0usize, 0.0f32, 0usize);
            for chunk in vidx.chunks(batch_size.max(1)) {
                let seqs: Vec<TokenSeq> = chunk.iter().map(|&i| val_samples[i].tokens).collect();
                let targets: Vec<u16> = chunk.iter().map(|&i| val_samples[i].target).collect();
                let (c, cs) = net::policy_eval(&vnet, &seqs, &targets, device);
                correct += c;
                ce += cs;
                n += chunk.len();
            }
            let acc = correct as f32 / n.max(1) as f32;
            let vce = ce / n.max(1) as f32;
            let star = if acc > best_acc { "  *best" } else { "" };
            println!(
                "Iter {}/{}: policy={:.4} value={:.4}  Eval @ val_acc={:.4} val_ce={:.4}  ({:.1}s){}",
                epoch + 1, epochs, tpl / nb.max(1) as f64, tvl / nb.max(1) as f64, acc, vce, t0.elapsed().as_secs_f32(), star
            );
            // Win-rate eval every N epochs (ASTRA7.md §4.1's actual gate —
            // 2026-07-09: a mid-training checkpoint hit 92.8% val_acc but
            // only 14% win_rate, well below both the >=25% floor and v6's
            // own 16% BC baseline. Token-accuracy and win-rate can diverge
            // sharply (compounding-error distribution shift is the expected
            // mechanism, but only measuring it catches it — that gap sat
            // undetected for 5+ hours before a manual check surfaced it).
            // Wired in here, not as a separate manual step, so a bad run
            // gets caught within one epoch instead of at the very end.
            if winrate_every > 0 && (epoch + 1) % winrate_every == 0 {
                let wt0 = Instant::now();
                let wr = eval_win_rate(&vnet, device, winrate_games, num_players);
                println!(
                    "  winrate@epoch{}: {:.4}  (n={}, {:.1}s)  [gate: >=0.25 floor, 0.30-0.40 target]",
                    epoch + 1, wr, winrate_games, wt0.elapsed().as_secs_f32()
                );
            }
            if acc > best_acc {
                best_acc = acc;
                let _ = std::fs::remove_file(format!("{best_path}.bin"));
                if let Err(e) = net.clone().save_file(best_path.clone(), &recorder) {
                    eprintln!("Warning: best-checkpoint save failed: {e:?}");
                }
            }
        } else {
            println!(
                "Iter {}/{}: policy={:.4} value={:.4}  ({:.1}s)",
                epoch + 1, epochs, tpl / nb.max(1) as f64, tvl / nb.max(1) as f64, t0.elapsed().as_secs_f32()
            );
        }
    }

    if let Err(e) = net.save_file(out_path, &recorder) {
        eprintln!("Warning: final save failed: {e:?}");
    }
    println!("BC training complete -> {out_path}.bin (best checkpoint -> {best_path}.bin, val_acc={:.4})", best_acc.max(0.0));
}

// ── Per-ActionKind fidelity diagnostic (ASTRA7.md §1.1/§10) ────────────────
//
// Answers "is chain-response fidelity lagging other decision kinds" with
// real evidence on a saved checkpoint, instead of an aggregate accuracy
// number that could hide exactly that gap. Free to run (forward-only,
// no training) — the recommended step before trusting a BC checkpoint or
// spending money scaling it up.

fn run_fidelity<B: Backend>(model_path: &str, samples: &[Sample], batch_size: usize, device: &B::Device) {
    let recorder = BinFileRecorder::<FullPrecisionSettings>::new();
    let net = Net::<B>::fresh(device)
        .load_file(model_path.to_string(), &recorder, device)
        .unwrap_or_else(|e| panic!("Failed to load {model_path}: {e:?}"));

    let idx: Vec<usize> = (0..samples.len()).collect();
    let mut buckets = [(0usize, 0usize, 0.0f32); NUM_ACTION_KINDS];
    for chunk in idx.chunks(batch_size.max(1)) {
        let seqs: Vec<TokenSeq> = chunk.iter().map(|&i| samples[i].tokens).collect();
        let targets: Vec<u16> = chunk.iter().map(|&i| samples[i].target).collect();
        let b = net::policy_eval_by_kind(&net, &seqs, &targets, device);
        for k in 0..NUM_ACTION_KINDS {
            buckets[k].0 += b[k].0;
            buckets[k].1 += b[k].1;
            buckets[k].2 += b[k].2;
        }
    }

    let (mut tot_c, mut tot_n, mut tot_ce) = (0usize, 0usize, 0.0f32);
    println!("\n{:<32} {:>8} {:>10} {:>10}", "ActionKind", "n", "accuracy", "mean_ce");
    println!("{:-<62}", "");
    for k in 0..NUM_ACTION_KINDS {
        let (c, n, ce) = buckets[k];
        if n == 0 {
            continue;
        }
        tot_c += c;
        tot_n += n;
        tot_ce += ce;
        println!(
            "{:<32} {:>8} {:>9.1}% {:>10.4}",
            action_kind_name(k as u8),
            n,
            100.0 * c as f32 / n as f32,
            ce / n as f32
        );
    }
    println!("{:-<62}", "");
    println!(
        "{:<32} {:>8} {:>9.1}% {:>10.4}",
        "TOTAL",
        tot_n,
        100.0 * tot_c as f32 / tot_n.max(1) as f32,
        tot_ce / tot_n.max(1) as f32
    );
    println!(
        "\nNote: ChainResponsePass/ChainResponseCard rows are the ASTRA7.md §1.1 chain-response\n\
         fidelity check — if their accuracy trails other rows by a wide margin, that's the signal\n\
         to un-defer history token event-type tagging (tokens.rs's reserved fields[0] on History\n\
         tokens) rather than growing the model."
    );
}

fn cmd_fidelity(args: &[String]) {
    let model_path = flag_str(args, "--model", "models/astra7_bc_best.bin");
    let val_games = flag_usize(args, "--val-games", 200);
    let num_players = flag_usize(args, "--players", 4);
    let batch_size = flag_usize(args, "--batch-size", 64);

    println!("Fidelity check: model={model_path}  games={val_games}");
    let t0 = Instant::now();
    let samples = generate_samples(val_games, num_players);
    println!("  {} samples in {:.1}s", samples.len(), t0.elapsed().as_secs_f32());

    #[cfg(feature = "tch")]
    {
        let device = LibTorchDevice::Cuda(0);
        run_fidelity::<LibTorch<f32>>(&model_path, &samples, batch_size, &device);
        return;
    }
    #[cfg(not(feature = "tch"))]
    {
        let device = NdArrayDevice::Cpu;
        run_fidelity::<NdArray>(&model_path, &samples, batch_size, &device);
    }
}

/// Standalone CLI wrapper around `az::eval_win_rate` (ASTRA7.md §4.1's
/// "milestone eval": greedy net vs AdvCPU, no search) — the function
/// already existed for AZ's own in-loop evals, this just exposes it against
/// any checkpoint (BC, TD-value, or AZ) without needing a full AZ run.
fn cmd_winrate(args: &[String]) {
    let model_path = flag_str(args, "--model", "models/astra7_bc_best.bin");
    let games = flag_usize(args, "--games", 200);
    let num_players = flag_usize(args, "--players", 4);

    let recorder = BinFileRecorder::<FullPrecisionSettings>::new();
    println!("Winrate eval (ASTRA7.md §4.1/§2): model={model_path}  games={games}  players={num_players}");
    let t0 = Instant::now();

    #[cfg(feature = "tch")]
    {
        let device = LibTorchDevice::Cuda(0);
        let net = Net::<LibTorch<f32>>::fresh(&device)
            .load_file(model_path.to_string(), &recorder, &device)
            .unwrap_or_else(|e| panic!("Failed to load {model_path}: {e:?}"));
        let rate = eval_win_rate(&net, &device, games, num_players);
        println!("win_rate={:.4}  ({:.1}s)", rate, t0.elapsed().as_secs_f32());
        return;
    }
    #[cfg(not(feature = "tch"))]
    {
        let device = NdArrayDevice::Cpu;
        let net = Net::<NdArray>::fresh(&device)
            .load_file(model_path.to_string(), &recorder, &device)
            .unwrap_or_else(|e| panic!("Failed to load {model_path}: {e:?}"));
        let rate = eval_win_rate(&net, &device, games, num_players);
        println!("win_rate={:.4}  ({:.1}s)", rate, t0.elapsed().as_secs_f32());
    }
}

fn cmd_bc(args: &[String]) {
    let out_path = flag_str(args, "--out", "models/astra7_bc.bin");
    let num_games = flag_usize(args, "--games", 0);
    let chunk_games = flag_usize(args, "--chunk-games", 2000);
    let num_players = flag_usize(args, "--players", 4);
    let lr = flag_f32(args, "--lr", 0.0003);
    let epochs = flag_usize(args, "--epochs", 15);
    let batch_size = flag_usize(args, "--batch-size", 64);
    let label_smoothing = flag_f32(args, "--label-smoothing", 0.05);
    let val_games = flag_usize(args, "--val-games", 200);
    // Real win-rate gate (ASTRA7.md §4.1), not just token-accuracy — found
    // 2026-07-09 that these can diverge sharply (92.8% val_acc, 14% win_rate
    // on the same checkpoint). every=1 by default: the eval itself is cheap
    // (~130s/200 games) against a multi-hour epoch; every=0 disables it.
    let winrate_every = flag_usize(args, "--winrate-every", 1);
    let winrate_games = flag_usize(args, "--winrate-games", 150);

    if let Some(parent) = std::path::Path::new(&out_path).parent() {
        if !parent.as_os_str().is_empty() {
            std::fs::create_dir_all(parent).ok();
        }
    }

    let model_path = flag_str(args, "--model", "");

    // Backend selection (ASTRA7.md §3.3/§5): `tch` feature -> LibTorch/CUDA
    // on Atlas (Autodiff<LibTorch<f32>>, device Cuda(0)); default ->
    // burn-ndarray CPU, kept so hermes-side quick sanity runs/tests still
    // work without needing Atlas. Mirrors ml/src/main.rs's gpu/not(gpu) split.
    #[cfg(feature = "tch")]
    {
        let device = LibTorchDevice::Cuda(0);
        type B = Autodiff<LibTorch<f32>>;

        let initial: Option<Net<B>> = if !model_path.is_empty() {
            println!("Warm start from {model_path}");
            let recorder = BinFileRecorder::<FullPrecisionSettings>::new();
            Some(
                Net::<B>::fresh(&device)
                    .load_file(model_path.clone(), &recorder, &device)
                    .unwrap_or_else(|e| panic!("Failed to load {model_path}: {e:?}")),
            )
        } else {
            None
        };

        run_bc::<B>(
            initial, &out_path, num_games, chunk_games, num_players, lr, epochs, batch_size, label_smoothing,
            val_games, winrate_every, winrate_games, &device,
        );
        return;
    }
    #[cfg(not(feature = "tch"))]
    {
        let device = NdArrayDevice::Cpu;
        type B = Autodiff<NdArray>;

        let initial: Option<Net<B>> = if !model_path.is_empty() {
            println!("Warm start from {model_path}");
            let recorder = BinFileRecorder::<FullPrecisionSettings>::new();
            Some(
                Net::<B>::fresh(&device)
                    .load_file(model_path.clone(), &recorder, &device)
                    .unwrap_or_else(|e| panic!("Failed to load {model_path}: {e:?}")),
            )
        } else {
            None
        };

        run_bc::<B>(
            initial, &out_path, num_games, chunk_games, num_players, lr, epochs, batch_size, label_smoothing,
            val_games, winrate_every, winrate_games, &device,
        );
    }
}

// ── TD-value training (ASTRA7.md §4.2) ──────────────────────────────────
//
// Each "pass" regenerates a fresh self-play chunk (net's own policy,
// temperature-sampled — see td_value.rs) and does ONE frozen-trunk training
// sweep over it. "2-3 passes" (§4.2) means 2-3 such regenerate+train
// rounds, not 2-3 epochs over one fixed dataset — see td_value.rs's module
// doc for why TD targets are computed once per chunk rather than
// re-bootstrapped mid-pass.

fn value_mse<B: Backend>(net: &Net<B>, seqs: &[TokenSeq], targets: &[f32], device: &B::Device) -> f32 {
    if seqs.is_empty() {
        return 0.0;
    }
    let (_, values) = net::forward(net, seqs, device);
    let preds = values.into_data().to_vec::<f32>().unwrap_or_default();
    preds.iter().zip(targets.iter()).map(|(p, t)| (p - t) * (p - t)).sum::<f32>() / preds.len().max(1) as f32
}

#[allow(clippy::too_many_arguments)]
fn run_td_value<B: AutodiffBackend>(
    initial: Net<B>,
    out_path: &str,
    chunk_games: usize,
    passes: usize,
    num_players: usize,
    temperature: f32,
    lr: f32,
    batch_size: usize,
    val_games: usize,
    device: &B::Device,
) where
    B::Device: Clone + Sync,
{
    let mut net = initial;
    let mut opt = net::make_optimizer::<B>();
    let mut rng = thread_rng();
    let recorder = BinFileRecorder::<FullPrecisionSettings>::new();
    let best_path = best_checkpoint_path(out_path);
    let mut best_val_mse = f32::MAX;

    for pass in 0..passes {
        let t0 = Instant::now();
        let vnet = net.valid(); // ASTRA7.md §8.2: self-play generation is forward-only
        println!("TD-value pass {}/{}: generating {} self-play games (T={temperature})...", pass + 1, passes, chunk_games);
        let samples: Vec<TdSample> = generate_td_samples(&vnet, device, chunk_games, num_players, temperature);
        println!("  {} samples in {:.1}s", samples.len(), t0.elapsed().as_secs_f32());
        if samples.len() < 2 {
            continue;
        }

        let mut idx: Vec<usize> = (0..samples.len()).collect();
        idx.shuffle(&mut rng);

        const HEARTBEAT_EVERY: usize = 100;
        let total_batches = samples.len().div_ceil(batch_size).max(1);
        let (mut tvl, mut nb) = (0.0f64, 0usize);
        let t1 = Instant::now();
        for chunk in idx.chunks(batch_size) {
            if chunk.len() < 2 {
                continue;
            }
            let seqs: Vec<TokenSeq> = chunk.iter().map(|&i| samples[i].tokens).collect();
            let targets: Vec<f32> = chunk.iter().map(|&i| samples[i].td_target).collect();
            let (nn, vl) = net::td_train_step(net, &mut opt, lr as f64, &seqs, &targets, device);
            net = nn;
            tvl += vl as f64;
            nb += 1;
            if nb % HEARTBEAT_EVERY == 0 {
                println!(
                    "    heartbeat: batch {}/{}  value_mse={:.4}  {:.2}s elapsed",
                    nb, total_batches, tvl / nb as f64, t1.elapsed().as_secs_f32()
                );
            }
        }

        if val_games > 0 {
            let vnet2 = net.valid();
            let val_samples = generate_td_samples(&vnet2, device, val_games, num_players, temperature);
            let (mut mse_sum, mut n) = (0.0f64, 0usize);
            for chunk in val_samples.chunks(batch_size.max(1)) {
                let seqs: Vec<TokenSeq> = chunk.iter().map(|s| s.tokens).collect();
                let targets: Vec<f32> = chunk.iter().map(|s| s.td_target).collect();
                mse_sum += value_mse(&vnet2, &seqs, &targets, device) as f64 * chunk.len() as f64;
                n += chunk.len();
            }
            let val_mse = if n > 0 { (mse_sum / n as f64) as f32 } else { 0.0 };
            let star = if val_mse < best_val_mse { "  *best" } else { "" };
            println!(
                "Pass {}/{}: train_value_mse={:.4}  val_value_mse={:.4}  ({:.1}s){}",
                pass + 1, passes, tvl / nb.max(1) as f64, val_mse, t0.elapsed().as_secs_f32(), star
            );
            if val_mse < best_val_mse {
                best_val_mse = val_mse;
                let _ = std::fs::remove_file(format!("{best_path}.bin"));
                if let Err(e) = net.clone().save_file(best_path.clone(), &recorder) {
                    eprintln!("Warning: best-checkpoint save failed: {e:?}");
                }
            }
        } else {
            println!(
                "Pass {}/{}: train_value_mse={:.4}  ({:.1}s)",
                pass + 1, passes, tvl / nb.max(1) as f64, t0.elapsed().as_secs_f32()
            );
        }
    }

    if let Err(e) = net.save_file(out_path, &recorder) {
        eprintln!("Warning: final save failed: {e:?}");
    }
    if best_val_mse == f32::MAX {
        // val_games=0 (or every pass produced <2 samples): no best-checkpoint
        // save ever ran, so best_path.bin doesn't exist — don't claim it does.
        println!("TD-value training complete -> {out_path}.bin (no --val-games, no best checkpoint saved)");
    } else {
        println!("TD-value training complete -> {out_path}.bin (best checkpoint -> {best_path}.bin, val_value_mse={best_val_mse:.4})");
    }
}

fn cmd_td_value(args: &[String]) {
    let out_path = flag_str(args, "--out", "models/astra7_td.bin");
    let model_path = flag_str(args, "--model", "");
    if model_path.is_empty() {
        eprintln!(
            "td-value requires --model <BC checkpoint> (ASTRA7.md §4.2: TD-value fine-tunes \
             a BC-trained value head with the trunk frozen — it doesn't train one from scratch)"
        );
        std::process::exit(1);
    }
    let chunk_games = flag_usize(args, "--chunk-games", 1500);
    let passes = flag_usize(args, "--passes", 3);
    let num_players = flag_usize(args, "--players", 4);
    let temperature = flag_f32(args, "--temperature", 0.8);
    let lr = flag_f32(args, "--lr", 0.001);
    let batch_size = flag_usize(args, "--batch-size", 64);
    let val_games = flag_usize(args, "--val-games", 200);

    if let Some(parent) = std::path::Path::new(&out_path).parent() {
        if !parent.as_os_str().is_empty() {
            std::fs::create_dir_all(parent).ok();
        }
    }

    #[cfg(feature = "tch")]
    {
        let device = LibTorchDevice::Cuda(0);
        type B = Autodiff<LibTorch<f32>>;
        let recorder = BinFileRecorder::<FullPrecisionSettings>::new();
        let net = Net::<B>::fresh(&device)
            .load_file(model_path.clone(), &recorder, &device)
            .unwrap_or_else(|e| panic!("Failed to load {model_path}: {e:?}"));
        run_td_value::<B>(net, &out_path, chunk_games, passes, num_players, temperature, lr, batch_size, val_games, &device);
        return;
    }
    #[cfg(not(feature = "tch"))]
    {
        let device = NdArrayDevice::Cpu;
        type B = Autodiff<NdArray>;
        let recorder = BinFileRecorder::<FullPrecisionSettings>::new();
        let net = Net::<B>::fresh(&device)
            .load_file(model_path.clone(), &recorder, &device)
            .unwrap_or_else(|e| panic!("Failed to load {model_path}: {e:?}"));
        run_td_value::<B>(net, &out_path, chunk_games, passes, num_players, temperature, lr, batch_size, val_games, &device);
    }
}

// ── value-rank diagnostic (ASTRA7.md §4.2) ──────────────────────────────

fn report_value_rank(rate: f32, n: usize, t0: Instant) {
    println!("value-rank: {n} decision points scored in {:.1}s", t0.elapsed().as_secs_f32());
    println!("  top-2 hit rate: {:.1}%  (gate: >=65.0%, ASTRA7.md §4.2)", rate * 100.0);
    if rate >= 0.65 {
        println!("  PASS — value head ranks successors well enough to trust MCTS leaf evals.");
    } else {
        println!("  FAIL — do not proceed to the AZ league until this clears the gate.");
    }
}

fn cmd_value_rank(args: &[String]) {
    let model_path = flag_str(args, "--model", "");
    if model_path.is_empty() {
        eprintln!("value-rank requires --model <path>");
        std::process::exit(1);
    }
    let num_games = flag_usize(args, "--games", 400);
    let target_points = flag_usize(args, "--points", 1000);
    let num_players = flag_usize(args, "--players", 4);

    println!("value-rank: model={model_path}  games={num_games}  target_points={target_points}");
    let t0 = Instant::now();

    #[cfg(feature = "tch")]
    {
        let device = LibTorchDevice::Cuda(0);
        let recorder = BinFileRecorder::<FullPrecisionSettings>::new();
        let net = Net::<LibTorch<f32>>::fresh(&device)
            .load_file(model_path.clone(), &recorder, &device)
            .unwrap_or_else(|e| panic!("Failed to load {model_path}: {e:?}"));
        let (rate, n) = evals::run_value_rank(&net, &device, num_games, num_players, target_points);
        report_value_rank(rate, n, t0);
        return;
    }
    #[cfg(not(feature = "tch"))]
    {
        let device = NdArrayDevice::Cpu;
        let recorder = BinFileRecorder::<FullPrecisionSettings>::new();
        let net = Net::<NdArray>::fresh(&device)
            .load_file(model_path.clone(), &recorder, &device)
            .unwrap_or_else(|e| panic!("Failed to load {model_path}: {e:?}"));
        let (rate, n) = evals::run_value_rank(&net, &device, num_games, num_players, target_points);
        report_value_rank(rate, n, t0);
    }
}

// ── AZ league (ASTRA7.md §4.3) ───────────────────────────────────────────

#[allow(clippy::too_many_arguments)]
fn run_az<B: AutodiffBackend>(
    initial: Net<B>,
    out_path: &str,
    iters: usize,
    games_per_iter: usize,
    num_players: usize,
    sims: usize,
    c_puct: f32,
    dirichlet_eps: f32,
    advcpu_share: f32,
    expert_share: f32,
    window: usize,
    batch_size: usize,
    lr_start: f32,
    lr_end: f32,
    snapshot_every: usize,
    eval_every: usize,
    eval_games: usize,
    device: &B::Device,
) where
    B::Device: Clone + Sync,
{
    let mut net = initial;
    let mut opt = net::make_optimizer::<B>();
    let mut rng = thread_rng();
    let recorder = BinFileRecorder::<FullPrecisionSettings>::new();
    let best_path = best_checkpoint_path(out_path);

    let cfg = McConfig { sims, c_puct, dirichlet_eps };
    let mut replay: Vec<AzSample> = Vec::new();
    let mut best_win_rate: f32 = -1.0;
    let mut eval_history: Vec<f32> = Vec::new();

    for iter in 0..iters {
        let t0 = Instant::now();
        let vnet = net.valid(); // ASTRA7.md §8.2: self-play generation is forward-only
        let fresh = generate_az_games(&vnet, device, &cfg, games_per_iter, num_players, advcpu_share, expert_share);
        println!(
            "Iter {}/{}: generated {} AZ samples from {} games ({:.1}s)",
            iter + 1, iters, fresh.len(), games_per_iter, t0.elapsed().as_secs_f32()
        );
        replay.extend(fresh);
        if replay.len() > window {
            // Sliding FIFO window (§4.3: 300K samples) — oldest self-play
            // drops off first.
            let excess = replay.len() - window;
            replay.drain(0..excess);
        }
        if replay.len() < 2 {
            continue;
        }

        // Cosine lr_start -> lr_end over the whole run (§4.3).
        let progress = iter as f32 / (iters.max(2) - 1) as f32;
        let lr = lr_end + 0.5 * (lr_start - lr_end) * (1.0 + (std::f32::consts::PI * progress).cos());

        // az-epochs=1 (§4.3, §8.4: "4 epochs oscillates") — ONE pass over
        // the CURRENT sliding window, not just this iteration's fresh batch.
        let mut idx: Vec<usize> = (0..replay.len()).collect();
        idx.shuffle(&mut rng);
        let (mut tpl, mut tvl, mut nb) = (0.0f64, 0.0f64, 0usize);
        let t1 = Instant::now();
        for chunk in idx.chunks(batch_size) {
            if chunk.len() < 2 {
                continue;
            }
            let seqs: Vec<TokenSeq> = chunk.iter().map(|&i| replay[i].tokens).collect();
            let visit_dists: Vec<[f32; ACTION_MAX]> = chunk.iter().map(|&i| replay[i].visit_dist).collect();
            let outcomes: Vec<f32> = chunk.iter().map(|&i| replay[i].outcome).collect();
            let (nn, pl, vl) = net::az_train_step(net, &mut opt, lr as f64, &seqs, &visit_dists, &outcomes, device);
            net = nn;
            tpl += pl as f64;
            tvl += vl as f64;
            nb += 1;
        }
        println!(
            "  train: policy={:.4} value={:.4}  lr={:.2e}  window={}  ({:.1}s)",
            tpl / nb.max(1) as f64, tvl / nb.max(1) as f64, lr, replay.len(), t1.elapsed().as_secs_f32()
        );

        if (iter + 1) % snapshot_every.max(1) == 0 {
            let snap = snapshot_path(out_path, iter + 1);
            match net.clone().save_file(snap.clone(), &recorder) {
                Ok(_) => println!("  snapshot -> {snap}.bin"),
                Err(e) => eprintln!("Warning: snapshot save failed: {e:?}"),
            }
        }

        if (iter + 1) % eval_every.max(1) == 0 || iter + 1 == iters {
            let t2 = Instant::now();
            let vnet2 = net.valid();
            let win_rate = eval_win_rate(&vnet2, device, eval_games, num_players);
            eval_history.push(win_rate);
            let star = if win_rate > best_win_rate { "  *best" } else { "" };
            println!(
                "  Eval @ iter {}: win_rate={:.1}% ({} games, {:.1}s){}",
                iter + 1, win_rate * 100.0, eval_games, t2.elapsed().as_secs_f32(), star
            );

            if win_rate > best_win_rate {
                best_win_rate = win_rate;
                let _ = std::fs::remove_file(format!("{best_path}.bin"));
                if let Err(e) = net.clone().save_file(best_path.clone(), &recorder) {
                    eprintln!("Warning: best-checkpoint save failed: {e:?}");
                }
            }

            // Restart-from-best with a fresh optimizer on two consecutive
            // declines (ASTRA7.md §2/§4.3 — "the v6 leg pattern, it works").
            let n = eval_history.len();
            if n >= 3 && eval_history[n - 1] < eval_history[n - 2] && eval_history[n - 2] < eval_history[n - 3] {
                println!("  Two consecutive eval declines -> restarting from best checkpoint with a fresh optimizer.");
                match Net::<B>::fresh(device).load_file(best_path.clone(), &recorder, device) {
                    Ok(reloaded) => {
                        net = reloaded;
                        opt = net::make_optimizer::<B>();
                        eval_history.clear();
                    }
                    Err(e) => eprintln!("  Warning: restart-from-best failed to load {best_path}.bin: {e:?} — continuing without restart."),
                }
            }
        }
    }

    if let Err(e) = net.save_file(out_path, &recorder) {
        eprintln!("Warning: final save failed: {e:?}");
    }
    if best_win_rate < 0.0 {
        // No eval ever ran (e.g. iters=0, or the replay window never reached
        // 2 samples) — best_path.bin was never written, don't claim it was.
        println!("AZ league complete -> {out_path}.bin (no eval ran, no best checkpoint saved)");
        return;
    }
    println!(
        "AZ league complete -> {out_path}.bin (best checkpoint -> {best_path}.bin, best_win_rate={:.1}%)",
        best_win_rate * 100.0
    );
}

fn cmd_az(args: &[String]) {
    let out_path = flag_str(args, "--out", "models/astra7_az.bin");
    let model_path = flag_str(args, "--model", "");
    if model_path.is_empty() {
        eprintln!(
            "az requires --model <TD-value checkpoint> (ASTRA7.md §4.3: the league continues \
             from a value-rank-gated checkpoint, it doesn't start from scratch)"
        );
        std::process::exit(1);
    }
    let iters = flag_usize(args, "--iters", 150);
    let games_per_iter = flag_usize(args, "--games-per-iter", 150);
    let num_players = flag_usize(args, "--players", 4);
    let sims = flag_usize(args, "--sims", 400);
    if sims < 400 {
        eprintln!(
            "Warning: --sims {sims} is below ASTRA7.md §4.3's floor of 400 — Dirichlet noise at \
             low sim counts crashed v6 (§8.5). Proceeding anyway (assuming a deliberate smoke test)."
        );
    }
    let c_puct = flag_f32(args, "--c-puct", 1.5);
    let dirichlet_eps = flag_f32(args, "--dirichlet-eps", 0.25);
    let advcpu_share = flag_f32(args, "--advcpu-share", 0.3);
    let expert_share = flag_f32(args, "--expert-share", 0.15);
    let window = flag_usize(args, "--window", 300_000);
    let batch_size = flag_usize(args, "--batch-size", 256);
    let lr_start = flag_f32(args, "--lr-start", 0.00005);
    let lr_end = flag_f32(args, "--lr-end", 0.00002);
    let snapshot_every = flag_usize(args, "--snapshot-every", 20);
    let eval_every = flag_usize(args, "--eval-every", 10);
    let eval_games = flag_usize(args, "--eval-games", 600);

    if let Some(parent) = std::path::Path::new(&out_path).parent() {
        if !parent.as_os_str().is_empty() {
            std::fs::create_dir_all(parent).ok();
        }
    }

    #[cfg(feature = "tch")]
    {
        let device = LibTorchDevice::Cuda(0);
        type B = Autodiff<LibTorch<f32>>;
        let recorder = BinFileRecorder::<FullPrecisionSettings>::new();
        let net = Net::<B>::fresh(&device)
            .load_file(model_path.clone(), &recorder, &device)
            .unwrap_or_else(|e| panic!("Failed to load {model_path}: {e:?}"));
        run_az::<B>(
            net, &out_path, iters, games_per_iter, num_players, sims, c_puct, dirichlet_eps, advcpu_share,
            expert_share, window, batch_size, lr_start, lr_end, snapshot_every, eval_every, eval_games, &device,
        );
        return;
    }
    #[cfg(not(feature = "tch"))]
    {
        let device = NdArrayDevice::Cpu;
        type B = Autodiff<NdArray>;
        let recorder = BinFileRecorder::<FullPrecisionSettings>::new();
        let net = Net::<B>::fresh(&device)
            .load_file(model_path.clone(), &recorder, &device)
            .unwrap_or_else(|e| panic!("Failed to load {model_path}: {e:?}"));
        run_az::<B>(
            net, &out_path, iters, games_per_iter, num_players, sims, c_puct, dirichlet_eps, advcpu_share,
            expert_share, window, batch_size, lr_start, lr_end, snapshot_every, eval_every, eval_games, &device,
        );
    }
}
