// ASTRA-7 AZ league (ASTRA7.md §4.3): MCTS-driven self-play generation,
// win-rate eval harness, and the opponent-mix game builder. Training itself
// (net::az_train_step) and the outer iterate/eval/restart-from-best loop
// live in main.rs (cmd_az/run_az), mirroring cmd_bc/run_bc's split.

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};

use rand::{thread_rng, Rng};

use burn::tensor::backend::Backend;

use novacana_engine::card::{Card, CardId};
use novacana_engine::chain::{Chain, ChainResumeCursor, ChainView};
use novacana_engine::cpu::{AdvancedCpuPlayer, ExpertCpuPlayer};
use novacana_engine::deck::Deck;
use novacana_engine::game::{GameEngine, GameState};
use novacana_engine::player::{Action, ChainAction, ChoiceRequest, GameView, Player, TargetOption};

use crate::mcts::{self, McConfig};
use crate::net::{self, Net};
use crate::sampling;
use crate::tokens::{self, ACTION_MAX, TokenSeq};

/// One AZ-seat's recorded (state tokens, MCTS/policy target) trajectory
/// buffer, shared between the Player impl and the game-runner that drains
/// it after the game ends.
type AzBuffer = Arc<Mutex<Vec<(TokenSeq, [f32; ACTION_MAX])>>>;

/// Decisions before visit-temperature sampling switches to greedy (ASTRA7.md
/// §4.3: "first 15 decisions of each game"). Counted per-GAME across ALL
/// seats and ALL five decision kinds (not just the two MCTS searches) —
/// ASTRA7.md doesn't specify whether this is per-seat or whole-game-wide;
/// whole-game-wide matches the standard AlphaZero "first N plies of the
/// game are exploratory" convention (a move number, not a per-player
/// budget), so that's what this implements. Revisit if self-play games look
/// under- or over-exploratory in practice.
const TEMP_MOVES: usize = 15;

pub struct AzSample {
    pub tokens: TokenSeq,
    pub visit_dist: [f32; ACTION_MAX],
    pub outcome: f32,
}

fn one_hot(idx: usize) -> [f32; ACTION_MAX] {
    let mut v = [0f32; ACTION_MAX];
    if idx < ACTION_MAX {
        v[idx] = 1.0;
    }
    v
}

// ── MCTS-driven self-play player ──────────────────────────────────────────

struct AzMctsPlayer<B: Backend> {
    name_str: String,
    net: Arc<Net<B>>,
    device: B::Device,
    cfg: McConfig,
    decisions_so_far: Arc<AtomicUsize>, // shared per-GAME move counter, see TEMP_MOVES
    buffer: AzBuffer,
}

impl<B: Backend> AzMctsPlayer<B> {
    fn move_temperature(&self) -> f32 {
        let n = self.decisions_so_far.fetch_add(1, Ordering::Relaxed);
        if n < TEMP_MOVES {
            1.0
        } else {
            0.0
        }
    }

    fn push(&self, tokens: TokenSeq, visit_dist: [f32; ACTION_MAX]) {
        self.buffer.lock().unwrap().push((tokens, visit_dist));
    }

    /// decide/pick_targets/choose_discards: no resumable engine continuation
    /// to search over (mcts.rs's module doc explains why), so this samples
    /// straight off the net's own policy and self-distills toward whichever
    /// index it actually picked (one-hot target) — same "start greedy /
    /// low-stakes" territory as §1.1's chain-response-is-the-real-lever
    /// finding, just extended to these three kinds for the AZ stage.
    fn decide_single(&self, view: &GameView, action_tokens: &[tokens::Token]) -> usize {
        let n = action_tokens.len();
        let temp = self.move_temperature();
        match tokens::assemble(view, action_tokens) {
            Some(enc) => {
                let (masked, _v) = net::forward_single(&self.net, &enc.tokens, &self.device);
                let idx = sampling::sample_temperature(&masked, n, temp, &mut thread_rng());
                self.push(enc.tokens, one_hot(idx));
                idx
            }
            None => 0,
        }
    }

    fn decide_multi(&self, view: &GameView, action_tokens: &[tokens::Token], count: usize) -> Vec<usize> {
        let n = action_tokens.len();
        let temp = self.move_temperature();
        match tokens::assemble(view, action_tokens) {
            Some(enc) => {
                let (masked, _v) = net::forward_single(&self.net, &enc.tokens, &self.device);
                let idxs = if count <= 1 {
                    vec![sampling::sample_temperature(&masked, n, temp, &mut thread_rng())]
                } else {
                    sampling::top_k_indices(&masked, n, count)
                };
                if let Some(&first) = idxs.first() {
                    self.push(enc.tokens, one_hot(first));
                }
                idxs
            }
            None => Vec::new(),
        }
    }
}

impl<B: Backend> Player for AzMctsPlayer<B> {
    fn name(&self) -> &str {
        &self.name_str
    }

    fn choose_action(&self, view: &GameView, legal: &[Action]) -> usize {
        // No-state fallback (shouldn't be hit — `run()` always calls the
        // _with_state variant, see engine/src/game.rs) — greedy raw policy.
        let action_tokens = tokens::encode_action_tokens_choose_action(view, legal);
        self.decide_single(view, &action_tokens)
    }

    fn choose_action_with_state(&self, view: &GameView, state: &GameState, legal: &[Action]) -> usize {
        let temp = self.move_temperature();
        let action_tokens = tokens::encode_action_tokens_choose_action(view, legal);
        let Some(enc) = tokens::assemble(view, &action_tokens) else {
            return 0;
        };
        let mut rng = thread_rng();
        let outcome = mcts::search_choose_action(&self.net, &self.device, view, state, legal, &self.cfg, temp, &mut rng);
        self.push(enc.tokens, outcome.visit_dist);
        outcome.chosen
    }

    fn respond_to_chain(&self, view: &GameView, _chain: &ChainView, legal: &[ChainAction]) -> Option<usize> {
        let action_tokens = tokens::encode_action_tokens_chain(view, legal);
        let idx = self.decide_single(view, &action_tokens);
        if idx == 0 {
            None
        } else {
            Some(idx - 1)
        }
    }

    fn respond_to_chain_with_state(
        &self,
        view: &GameView,
        state: &GameState,
        chain_view: &ChainView,
        chain: &Chain,
        cursor: ChainResumeCursor,
        legal: &[ChainAction],
    ) -> Option<usize> {
        let temp = self.move_temperature();
        let action_tokens = tokens::encode_action_tokens_chain(view, legal);
        let Some(enc) = tokens::assemble(view, &action_tokens) else {
            return self.respond_to_chain(view, chain_view, legal);
        };
        let mut rng = thread_rng();
        let outcome = mcts::search_chain_response(&self.net, &self.device, view, state, chain, cursor, legal, &self.cfg, temp, &mut rng);
        self.push(enc.tokens, outcome.visit_dist);
        if outcome.chosen == 0 {
            None
        } else {
            Some(outcome.chosen - 1)
        }
    }

    fn decide(&self, view: &GameView, req: &ChoiceRequest) -> usize {
        if req.options.is_empty() {
            return 0;
        }
        let action_tokens = tokens::encode_action_tokens_decide(view, req);
        self.decide_single(view, &action_tokens)
    }

    fn pick_targets(&self, view: &GameView, _prompt: &str, options: &[TargetOption], count: usize) -> Vec<usize> {
        if options.is_empty() {
            return Vec::new();
        }
        let action_tokens = tokens::encode_action_tokens_targets(view, options);
        self.decide_multi(view, &action_tokens, count)
    }

    fn choose_discards(&self, view: &GameView, hand: &[Card], must_discard: usize) -> Vec<CardId> {
        if hand.is_empty() {
            return Vec::new();
        }
        let action_tokens = tokens::encode_action_tokens_discards(hand);
        let idxs = self.decide_multi(view, &action_tokens, must_discard);
        idxs.into_iter().filter_map(|i| hand.get(i)).map(|c| c.id).collect()
    }
}

// ── Greedy (no-search) net player: used for fast win-rate evals ──────────

struct GreedyNetPlayer<B: Backend> {
    name_str: String,
    net: Arc<Net<B>>,
    device: B::Device,
}

impl<B: Backend> GreedyNetPlayer<B> {
    fn pick_single(&self, view: &GameView, action_tokens: &[tokens::Token]) -> usize {
        let n = action_tokens.len();
        match tokens::assemble(view, action_tokens) {
            Some(enc) => {
                let (masked, _v) = net::forward_single(&self.net, &enc.tokens, &self.device);
                sampling::argmax(&masked[..n])
            }
            None => 0,
        }
    }
    fn pick_multi(&self, view: &GameView, action_tokens: &[tokens::Token], count: usize) -> Vec<usize> {
        let n = action_tokens.len();
        match tokens::assemble(view, action_tokens) {
            Some(enc) => {
                let (masked, _v) = net::forward_single(&self.net, &enc.tokens, &self.device);
                sampling::top_k_indices(&masked, n, count)
            }
            None => Vec::new(),
        }
    }
}

impl<B: Backend> Player for GreedyNetPlayer<B> {
    fn name(&self) -> &str {
        &self.name_str
    }
    fn choose_action(&self, view: &GameView, legal: &[Action]) -> usize {
        self.pick_single(view, &tokens::encode_action_tokens_choose_action(view, legal))
    }
    fn respond_to_chain(&self, view: &GameView, _chain: &ChainView, legal: &[ChainAction]) -> Option<usize> {
        let idx = self.pick_single(view, &tokens::encode_action_tokens_chain(view, legal));
        if idx == 0 {
            None
        } else {
            Some(idx - 1)
        }
    }
    fn decide(&self, view: &GameView, req: &ChoiceRequest) -> usize {
        if req.options.is_empty() {
            return 0;
        }
        self.pick_single(view, &tokens::encode_action_tokens_decide(view, req))
    }
    fn pick_targets(&self, view: &GameView, _prompt: &str, options: &[TargetOption], count: usize) -> Vec<usize> {
        if options.is_empty() {
            return Vec::new();
        }
        self.pick_multi(view, &tokens::encode_action_tokens_targets(view, options), count)
    }
    fn choose_discards(&self, view: &GameView, hand: &[Card], must_discard: usize) -> Vec<CardId> {
        if hand.is_empty() {
            return Vec::new();
        }
        let idxs = self.pick_multi(view, &tokens::encode_action_tokens_discards(hand), must_discard);
        idxs.into_iter().filter_map(|i| hand.get(i)).map(|c| c.id).collect()
    }
}

// ── Self-play generation with opponent mix (ASTRA7.md §4.3) ──────────────

enum Role {
    Az,
    AdvCpu,
    Expert,
}

fn pick_role(rng: &mut impl Rng, advcpu_share: f32, expert_share: f32) -> Role {
    let r: f32 = rng.gen();
    if r < advcpu_share {
        Role::AdvCpu
    } else if r < advcpu_share + expert_share {
        Role::Expert
    } else {
        Role::Az
    }
}

/// One self-play game: each seat independently rolled into AdvCPU / Expert /
/// AZ-MCTS per the opponent-mix shares. Only AZ-seat decisions produce
/// training samples (the whole point of the mix is exposing the net to
/// stronger/different play, not supervising off AdvCPU's/Expert's choices —
/// that's BC's job). Capped at 400 turns per ASTRA7.md §8.1 ("Cap AZ outer
/// games at 400 turns (`run_one_az_game`), not 1000").
#[allow(clippy::too_many_arguments)]
fn run_one_az_game<B: Backend>(
    net: &Arc<Net<B>>,
    device: &B::Device,
    cfg: &McConfig,
    num_players: usize,
    advcpu_share: f32,
    expert_share: f32,
) -> Vec<AzSample>
where
    B::Device: Clone,
{
    let mut rng = thread_rng();
    let decisions_so_far = Arc::new(AtomicUsize::new(0));
    let mut bufs: Vec<Option<AzBuffer>> = Vec::new();
    let mut players: Vec<Box<dyn Player>> = Vec::new();

    for i in 0..num_players {
        match pick_role(&mut rng, advcpu_share, expert_share) {
            Role::AdvCpu => {
                bufs.push(None);
                players.push(Box::new(AdvancedCpuPlayer::new(format!("AdvCPU{}", i + 1))));
            }
            Role::Expert => {
                bufs.push(None);
                players.push(Box::new(ExpertCpuPlayer::new(format!("Expert{}", i + 1))));
            }
            Role::Az => {
                let buf = Arc::new(Mutex::new(Vec::new()));
                bufs.push(Some(Arc::clone(&buf)));
                players.push(Box::new(AzMctsPlayer {
                    name_str: format!("AzNet{}", i + 1),
                    net: Arc::clone(net),
                    device: device.clone(),
                    cfg: McConfig { sims: cfg.sims, c_puct: cfg.c_puct, dirichlet_eps: cfg.dirichlet_eps },
                    decisions_so_far: Arc::clone(&decisions_so_far),
                    buffer: buf,
                }));
            }
        }
    }

    let mut engine = GameEngine::new(Deck::build_classic(), players);
    engine.set_silent();
    engine.set_max_turns(400);
    let result = engine.run();

    let mut out = Vec::new();
    for (player_idx, buf) in bufs.into_iter().enumerate() {
        let Some(buf) = buf else { continue };
        let outcome = if result.winner_idx == player_idx { 1.0f32 } else { 0.0 };
        let trajectory = Arc::try_unwrap(buf)
            .unwrap_or_else(|b| Mutex::new(std::mem::take(&mut *b.lock().unwrap())))
            .into_inner()
            .unwrap();
        out.extend(trajectory.into_iter().map(|(tokens, visit_dist)| AzSample { tokens, visit_dist, outcome }));
    }
    out
}

/// Generate one iteration's worth of AZ self-play samples. Rayon-parallel
/// across games (embarrassingly parallel — ASTRA7.md §10). `net` must
/// already be forward-only (pass `net.valid()`, ASTRA7.md §8.2).
#[allow(clippy::too_many_arguments)]
pub fn generate_az_games<B: Backend>(
    net: &Net<B>,
    device: &B::Device,
    cfg: &McConfig,
    num_games: usize,
    num_players: usize,
    advcpu_share: f32,
    expert_share: f32,
) -> Vec<AzSample>
where
    B::Device: Clone + Sync,
{
    use rayon::prelude::*;
    let net = Arc::new(net.clone());
    (0..num_games)
        .into_par_iter()
        .flat_map(|_| run_one_az_game(&net, device, cfg, num_players, advcpu_share, expert_share))
        .collect()
}

/// Verified win-rate eval (ASTRA7.md §2): seat 0 = greedy (no-search) net,
/// seats 1..N = AdvancedCpuPlayer. No-search rather than full MCTS at eval
/// time for speed — 600/1000-game evals at >=400 sims/decision would be
/// prohibitively slow, and this matches how `fidelity`/BC's existing evals
/// in this codebase already measure "full-ML" strength (raw policy, no
/// search) rather than search-assisted play.
pub fn eval_win_rate<B: Backend>(net: &Net<B>, device: &B::Device, num_games: usize, num_players: usize) -> f32
where
    B::Device: Clone + Sync,
{
    use rayon::prelude::*;
    let net = Arc::new(net.clone());
    let wins: usize = (0..num_games)
        .into_par_iter()
        .map(|_| {
            let mut players: Vec<Box<dyn Player>> = Vec::new();
            players.push(Box::new(GreedyNetPlayer { name_str: "AzEvalNet".into(), net: Arc::clone(&net), device: device.clone() }));
            for i in 1..num_players {
                players.push(Box::new(AdvancedCpuPlayer::new(format!("AdvCPU{}", i + 1))));
            }
            let mut engine = GameEngine::new(Deck::build_classic(), players);
            engine.set_silent();
            engine.set_max_turns(400);
            let result = engine.run();
            (result.winner_idx == 0) as usize
        })
        .sum();
    wins as f32 / num_games.max(1) as f32
}

#[cfg(test)]
mod tests {
    use super::*;
    use burn_ndarray::NdArray;
    use burn_ndarray::NdArrayDevice;

    #[test]
    fn self_play_produces_samples_with_valid_distributions() {
        let device = NdArrayDevice::Cpu;
        let net = Net::<NdArray>::fresh(&device);
        // Tiny sims count + all-AZ seats (no AdvCPU/Expert dilution) so the
        // test exercises the MCTS path and finishes quickly. One game is
        // enough to touch all five decision kinds at this scale (a full
        // game with a fresh net still runs dozens of decisions) — 2 games
        // roughly doubled wall time for no extra coverage.
        let cfg = McConfig { sims: 4, c_puct: 1.5, dirichlet_eps: 0.25 };
        let samples = generate_az_games(&net, &device, &cfg, 1, 4, 0.0, 0.0);
        assert!(!samples.is_empty(), "expected at least some AZ samples from 1 game");
        for s in &samples {
            let sum: f32 = s.visit_dist.iter().sum();
            assert!((sum - 1.0).abs() < 1e-3, "visit_dist must sum to ~1, got {sum}");
            assert!(s.outcome == 0.0 || s.outcome == 1.0);
        }
    }

    #[test]
    fn eval_win_rate_returns_a_fraction() {
        let device = NdArrayDevice::Cpu;
        let net = Net::<NdArray>::fresh(&device);
        let rate = eval_win_rate(&net, &device, 2, 4);
        assert!((0.0..=1.0).contains(&rate));
    }
}
